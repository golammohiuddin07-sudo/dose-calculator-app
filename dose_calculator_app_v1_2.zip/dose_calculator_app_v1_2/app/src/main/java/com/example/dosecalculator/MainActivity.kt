package com.example.dosecalculator

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.dialog_preset.view.*
import kotlin.math.round

data class PresetItem(
    var id: Long,
    var name: String,
    var isMgPerKg: Boolean,
    var pediatricDose: String?, // can be range like "10-15"
    var adultDose: String?, // mg per unit or mg
    var unitStrength: Int? // optional mg per tablet
)

class MainActivity : AppCompatActivity() {

    private val PREFS = "dose_prefs"
    private val KEY_PRESETS = "presets_json"
    private val gson = Gson()
    private var presets = mutableListOf<PresetItem>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadDefaultPresets()
        setupUI()
    }

    private fun setupUI() {
        adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, presets.map { it.name })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        presets_spinner.adapter = adapter

        presets_spinner.setSelection(0)
        presets_spinner.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val p = presets[position]
                // populate fields based on adult/pediatric toggle
                if (adult_radio.isChecked) {
                    quantity_input.setText(p.adultDose ?: "")
                    mode_switch.isChecked = !(p.unitStrength != null)
                    unit_strength_input.setText(p.unitStrength?.toString() ?: "")
                } else {
                    quantity_input.setText(p.pediatricDose ?: "")
                    mode_switch.isChecked = true
                }
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        })

        // Save custom preset button
        save_preset_button.setOnClickListener { showSavePresetDialog(null) }
        edit_preset_button.setOnClickListener { showEditDeleteDialog() }

        mode_switch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                quantity_input.hint = getString(R.string.hint_quantity_mg_per_kg)
                unit_strength_input.visibility = View.GONE
            } else {
                quantity_input.hint = getString(R.string.hint_quantity_mg_per_unit)
                unit_strength_input.visibility = View.VISIBLE
            }
        }

        calc_button.setOnClickListener { calculate() }
        clear_button.setOnClickListener { clearInputs() }

        quantity_input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                calculate(); true
            } else false
        }
    }

    private fun showSavePresetDialog(editId: Long?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_preset, null)
        val dialog = AlertDialog.Builder(this).setTitle(
            if (editId == null) getString(R.string.save_new_preset) else getString(R.string.edit_preset)
        ).setView(view).setPositiveButton(android.R.string.ok, null).setNegativeButton(android.R.string.cancel, null).create()

        // If editing, fill fields
        if (editId != null) {
            val p = presets.find { it.id == editId }
            if (p != null) {
                view.preset_name.setText(p.name)
                view.preset_pediatric.setText(p.pediatricDose ?: "")
                view.preset_adult.setText(p.adultDose ?: "")
                view.preset_unit_strength.setText(p.unitStrength?.toString() ?: "")
                view.preset_mode_mgkg.isChecked = p.isMgPerKg
            }
        }

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = view.preset_name.text.toString().trim()
                if (name.isEmpty()) {
                    view.preset_name.error = getString(R.string.enter_name)
                    return@setOnClickListener
                }
                val pediatric = view.preset_pediatric.text.toString().trim().ifEmpty { null }
                val adult = view.preset_adult.text.toString().trim().ifEmpty { null }
                val unitStr = view.preset_unit_strength.text.toString().trim().ifEmpty { null }
                val unit = unitStr?.toIntOrNull()
                val isMgPerKg = view.preset_mode_mgkg.isChecked

                if (editId == null) {
                    val newId = System.currentTimeMillis()
                    presets.add(PresetItem(newId, name, isMgPerKg, pediatric, adult, unit))
                } else {
                    val p = presets.find { it.id == editId }
                    if (p != null) {
                        p.name = name; p.pediatricDose = pediatric; p.adultDose = adult; p.unitStrength = unit; p.isMgPerKg = isMgPerKg
                    }
                }
                savePresets()
                refreshPresetSpinner()
                dialog.dismiss()
                Toast.makeText(this, getString(R.string.preset_saved), Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun showEditDeleteDialog() {
        val position = presets_spinner.selectedItemPosition
        if (position < 0) { Snackbar.make(root_layout, getString(R.string.select_preset_to_edit), Snackbar.LENGTH_SHORT).show(); return }
        val p = presets[position]
        val items = arrayOf(getString(R.string.edit_preset), getString(R.string.delete_preset))
        AlertDialog.Builder(this).setTitle(p.name).setItems(items) { _, which ->
            if (which == 0) {
                showSavePresetDialog(p.id)
            } else {
                // delete
                AlertDialog.Builder(this).setMessage(getString(R.string.confirm_delete, p.name))
                    .setPositiveButton(android.R.string.yes) { _, _ ->
                        presets.removeAt(position)
                        savePresets()
                        refreshPresetSpinner()
                        Toast.makeText(this, getString(R.string.preset_deleted), Toast.LENGTH_SHORT).show()
                    }.setNegativeButton(android.R.string.no, null).show()
            }
        }.show()
    }

    private fun calculate() {
        try {
            val isMgPerKg = mode_switch.isChecked
            val quantityVal = quantity_input.text.toString().toDoubleOrNull()
            val weightKg = weight_input.text.toString().toDoubleOrNull()
            val timesPerDay = times_input.text.toString().toDoubleOrNull() ?: 1.0
            val unitStrength = unit_strength_input.text.toString().toDoubleOrNull()

            if (timesPerDay <= 0.0) { Snackbar.make(root_layout, getString(R.string.enter_times), Snackbar.LENGTH_SHORT).show(); return }

            val sb = StringBuilder()
            if (isMgPerKg) {
                if (quantityVal == null || weightKg == null) {
                    Snackbar.make(root_layout, getString(R.string.enter_valid_numbers), Snackbar.LENGTH_SHORT).show(); return
                }
                // quantityVal may be a range like "10-15"
                val mgPerKg = quantityVal
                val singleDoseMg = mgPerKg * weightKg
                val totalDayMg = singleDoseMg * timesPerDay
                sb.append(getString(R.string.assuming_mg_per_kg)).append("\n")
                sb.append(String.format(getString(R.string.single_dose_fmt), formatNum(singleDoseMg))).append("\n")
                sb.append(String.format(getString(R.string.total_day_fmt), timesPerDay, formatNum(totalDayMg))).append("\n")
                if (unitStrength != null && unitStrength > 0.0) {
                    val unitsPerDose = singleDoseMg / unitStrength
                    sb.append(String.format(getString(R.string.units_needed_fmt), formatNum(unitsPerDose))).append("\n")
                } else sb.append(getString(R.string.hint_unit_strength_help)).append("\n")
            } else {
                if (quantityVal == null) {
                    Snackbar.make(root_layout, getString(R.string.enter_valid_numbers), Snackbar.LENGTH_SHORT).show(); return
                }
                val mgPerUnit = quantityVal
                sb.append(getString(R.string.assuming_mg_per_unit)).append("\n")
                sb.append(String.format(getString(R.string.unit_strength_display_fmt), formatNum(mgPerUnit))).append("\n")
                if (weightKg != null) {
                    val mgPerKgAchieved = mgPerUnit / weightKg
                    sb.append(String.format(getString(R.string.achieved_mg_per_kg_fmt), formatNum(mgPerKgAchieved))).append("\n")
                }
                sb.append(getString(R.string.hint_unit_mode_help)).append("\n")
            }
            result_text.text = sb.toString()
        } catch (e: Exception) {
            Snackbar.make(root_layout, "Error: ${e.message}", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun formatNum(v: Double): String {
        return if (v == v.toLong().toDouble()) String.format("%d", v.toLong()) else String.format("%.2f", v)
    }

    private fun clearInputs() {
        quantity_input.text?.clear()
        weight_input.text?.clear()
        times_input.text?.clear()
        unit_strength_input.text?.clear()
        result_text.text = ""
        presets_spinner.setSelection(0)
    }

    // Preset storage
    private fun savePresets() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = gson.toJson(presets)
        prefs.edit().putString(KEY_PRESETS, json).apply()
    }

    private fun loadPresetsFromStorage(): Boolean {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_PRESETS, null) ?: return False
        return try {
            val type = object : TypeToken<MutableList<PresetItem>>() {}.type
            presets = gson.fromJson(json, type)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun loadDefaultPresets() {
        // try load saved first
        val ok = loadPresetsFromStorage()
        if (ok) { refreshPresetSpinner(); return }

        presets = mutableListOf(
            PresetItem(1, "Paracetamol (Pediatric 15 mg/kg)", true, "15", "500", 500),
            PresetItem(2, "Paracetamol (Adult 500 mg)", false, null, "500", 500),
            PresetItem(3, "Ibuprofen (Pediatric 10 mg/kg)", true, "10", "200", 200),
            PresetItem(4, "Amoxicillin (Pediatric 25 mg/kg)", true, "25", "500", 500),
            PresetItem(5, "Azithromycin (Pediatric 10 mg/kg)", true, "10", "500", 500),
            PresetItem(6, "Cefixime (Pediatric 8 mg/kg)", true, "8", "200", 200),
            PresetItem(7, "Domperidone (Pediatric 0.3 mg/kg)", true, "0.3", "10", 10)
        )
        refreshPresetSpinner()
    }

    private fun refreshPresetSpinner() {
        adapter.clear()
        adapter.addAll(presets.map { it.name })
        adapter.notifyDataSetChanged()
        presets_spinner.adapter = adapter
        presets_spinner.setSelection(0)
    }

}
